import os, cv2, shutil, time, queue, threading, sqlite3, psutil
import numpy as np
from pathlib import Path
from tkinter import *
from tkinter import filedialog, messagebox, simpledialog
from tqdm import tqdm
from PIL import Image
import imagehash
from statistics import mean

# ----------- FACE ENGINE ------------
import insightface

providers = ["CPUExecutionProvider"]
try:
    import onnxruntime as ort
    if "DmlExecutionProvider" in ort.get_available_providers():
        providers = ["DmlExecutionProvider"]
        print("🔥 AMD DirectML Enabled!")
except:
    pass

print("Providers:", providers)
app = insightface.app.FaceAnalysis(name="buffalo_l", providers=providers)
app.prepare(ctx_id=-1, det_size=(640, 640))

# ----------- GLOBALS -------------
EXTS = (".jpg",".jpeg",".png",".bmp",".webp",".tif",".tiff")
ref_embs, matched = [], set()
src_folder = ""
out_folder = ""
file_q = queue.Queue()
time_records = []

# ----------- DB --------------
def db_init():
    con = sqlite3.connect("results.db")
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS matches(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ref TEXT,
        file TEXT,
        time TEXT
    )""")
    con.commit()
    return con, cur

con, cur = db_init()

# ----------- FUNCTIONS --------------
def get_emb(path):
    img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)
    faces = app.get(img)
    if not faces:
        raise Exception(f"No face: {path}")
    return faces[0].normed_embedding.astype(np.float32)

def cosine(a,b):
    return float(np.dot(a,b))

def phash(path):
    return str(imagehash.phash(Image.open(path)))

def worker(threshold, pbar, total_files, start_time):
    global time_records
    
    while True:
        f = file_q.get()
        if f is None: break

        t0 = time.time()

        if psutil.cpu_percent() > 85 or psutil.virtual_memory().percent > 85:
            time.sleep(1)

        try:
            img = cv2.imdecode(np.fromfile(str(f), np.uint8), cv2.IMREAD_COLOR)
            if img is not None:
                faces = app.get(img)
                if faces:
                    h = phash(f)

                    # Skip if already processed
                    if h in matched:
                        file_q.task_done()
                        pbar.update(1)
                        continue

                    for face in faces:
                        emb = face.normed_embedding.astype(np.float32)

                        # Best match among unlimited references
                        best = max(cosine(emb,r) for r in ref_embs)

                        if best >= threshold and h not in matched:
                            matched.add(h)

                            rel = f.relative_to(src_folder)
                            dst = Path(out_folder)/rel
                            dst.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(f, dst)

                            cur.execute(
                                "INSERT INTO matches(ref,file,time) VALUES (?,?,datetime('now'))",
                                (str(ref_embs),str(f))
                            )
                            con.commit()
                            break
        except:
            pass

        # timing ETA calculation
        t1 = time.time()
        time_records.append(t1-t0)
        if len(time_records) > 50:
            time_records.pop(0)

        avg = mean(time_records)
        done = pbar.n + 1
        remain = total_files - done
        eta = remain * avg
        elapsed = time.time() - start_time

        pbar.set_postfix({
            "⚡": f"{1/avg:.2f} img/s",
            "⏳": f"{eta/60:.1f}m",
            "⌛": f"{elapsed/60:.1f}m"
        })

        pbar.update(1)
        file_q.task_done()

# ----------- GUI CALLBACKS --------------
def pick_refs():
    global ref_embs

    # User chooses how many persons
    try:
        num_people = int(simpledialog.askstring("Reference faces", "რამდენი ადამიანის სახე გინდა მიუთითო?"))
    except:
        messagebox.showerror("Error", "გთხოვ მიუთითე რიცხვი")
        return

    if num_people <= 0:
        messagebox.showerror("Error", "რიცხვი უნდა იყოს 1-ზე მეტი")
        return

    messagebox.showinfo("Select photos", f"აირჩიე მინიმუმ {num_people} ადამიანის ფოტოები!")

    files = filedialog.askopenfilenames(
        title="Select reference faces",
        filetypes=[("Images","*.jpg *.png *.jpeg *.bmp *.webp")]
    )
    if not files:
        return

    if len(files) < num_people:
        messagebox.showerror("Error", f"უნდა აირჩიო მინიმუმ {num_people} ფოტო!")
        return

    try:
        ref_embs = [get_emb(p) for p in files]
        lbl_ref.config(text=f"✅ Loaded {len(ref_embs)} reference faces ({num_people} people)")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def pick_src():
    global src_folder
    src_folder = filedialog.askdirectory()
    lbl_src.config(text=f"📂 {src_folder}")

def pick_out():
    global out_folder
    out_folder = filedialog.askdirectory()
    lbl_out.config(text=f"💾 {out_folder}")

def start_scan():
    if not ref_embs or not src_folder or not out_folder:
        messagebox.showerror("Error","Select folders & reference faces")
        return

    files = [p for p in Path(src_folder).rglob("*") if p.suffix.lower() in EXTS]
    total_files = len(files)
    pbar = tqdm(total=total_files, desc="Scanning", dynamic_ncols=True)
    start_time = time.time()
    threshold = slider.get()/100

    for f in files:
        file_q.put(f)

    threads = []
    for _ in range(4):
        t = threading.Thread(target=worker, args=(threshold,pbar,total_files,start_time))
        t.start()
        threads.append(t)

    file_q.join()

    for _ in threads:
        file_q.put(None)
    for t in threads:
        t.join()

    pbar.close()
    messagebox.showinfo("Done",f"Matched photos: {len(matched)}")

# ----------- GUI --------------
root = Tk()
root.title("Face Finder PRO 🚀")
root.geometry("500x350")

Label(root, text="Face Finder PRO", font=("Arial",14,"bold")).pack(pady=5)

Button(root, text="1️⃣ Select Reference Faces", width=35, command=pick_refs).pack()
lbl_ref = Label(root,text="No reference"); lbl_ref.pack()

Button(root, text="2️⃣ Select Source Folder", width=35, command=pick_src).pack()
lbl_src = Label(root,text="None"); lbl_src.pack()

Button(root, text="3️⃣ Select Output Folder", width=35, command=pick_out).pack()
lbl_out = Label(root,text="None"); lbl_out.pack()

Label(root,text="Match Threshold").pack()
slider = Scale(root, from_=20, to=60, orient=HORIZONTAL, length=300)
slider.set(36); slider.pack()

Button(root, text="🚀 START", bg="#21794f", fg="white", width=40, command=start_scan).pack(pady=10)

root.mainloop()